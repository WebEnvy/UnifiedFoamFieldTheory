# UFFT Complete Package — March 2026

**The Unified Foam Field Theory**
**Author:** Luke Martin — Independent Researcher

---

## Package Contents

### 📄 /pdf/
Individual PDF files for each part of the framework, plus a combined complete works PDF.

- `UFFT_Complete_Works.pdf` — All parts combined with table of contents
- Individual parts: `00_preface.pdf`, `01_part_i.pdf`, etc.

### 📝 /markdown/
Markdown source files for use on GitHub or other platforms.

- `/individual/` — Separate markdown files for each part
- `/combined/` — Single combined markdown file

### 🌐 /web_visualizations/
Interactive HTML visualizations demonstrating key UFFT concepts.

- `index.html` — Main navigation page
- `01_foam_axiom_zero.html` — 3D foam cell and Axiom Zero visualization
- `02_bell_correlations.html` — Interactive Bell correlation explorer
- `03_predictions_dashboard.html` — Predictions status tracker
- `04_gravity_density_gradient.html` — Gravity from foam density

**To use:** Open `index.html` in any modern web browser. No server required.

### 📨 /submissions/
Journal submission materials.

- `/existing/` — Formatted versions of the two published preprints
  - Decoherence paper (DOI: 10.5281/zenodo.18706756)
  - Bell correlations paper (DOI: 10.5281/zenodo.18706806)
  
- `/templates/` — Templates and guides for future submissions
  - Cover letter template
  - arXiv submission guide
  - Journal strategy and target list

---

## Quick Start

1. **Read the framework:** Start with `pdf/01_part_i.pdf` for the complete theory
2. **Explore interactively:** Open `web_visualizations/index.html` in a browser
3. **Check predictions:** See `pdf/17_appendix.pdf` for falsifiable predictions
4. **For GitHub:** Upload the `/markdown/individual/` folder directly

---

## Mathematical Verification Status

- **Arithmetic errors:** 0
- **Dimensional inconsistencies:** 0
- **Verified predictions:** 15+
- **Open problems:** 2 (α derivation, covariant vacuum density)

---

## Priority DOIs

| Paper | DOI |
|-------|-----|
| Decoherence | 10.5281/zenodo.18706756 |
| Bell Correlations | 10.5281/zenodo.18706806 |

---

## AI Disclosure

Developed in collaboration with Claude (Anthropic).
- Ideas, theory, direction: Luke Martin
- Mathematical verification, document structuring: Claude

---

*Package generated: March 2026*
*Priority Date: 20 February 2026*
