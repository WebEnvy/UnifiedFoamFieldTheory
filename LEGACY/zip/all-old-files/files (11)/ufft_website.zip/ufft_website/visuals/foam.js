// UFFT Foam Visualization - Truncated Octahedron
(function() {
    const canvas = document.getElementById('foam-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    let angle = 0;
    
    // Truncated octahedron vertices (scaled)
    const scale = 80;
    const vertices = [
        [0, 1, 2], [0, 1, -2], [0, -1, 2], [0, -1, -2],
        [0, 2, 1], [0, 2, -1], [0, -2, 1], [0, -2, -1],
        [1, 0, 2], [1, 0, -2], [-1, 0, 2], [-1, 0, -2],
        [2, 0, 1], [2, 0, -1], [-2, 0, 1], [-2, 0, -1],
        [1, 2, 0], [1, -2, 0], [-1, 2, 0], [-1, -2, 0],
        [2, 1, 0], [2, -1, 0], [-2, 1, 0], [-2, -1, 0]
    ].map(v => v.map(c => c * scale));
    
    // Calculate edges (vertices distance ~2*scale apart)
    const edges = [];
    for (let i = 0; i < vertices.length; i++) {
        for (let j = i + 1; j < vertices.length; j++) {
            const d = Math.sqrt(
                Math.pow(vertices[i][0] - vertices[j][0], 2) +
                Math.pow(vertices[i][1] - vertices[j][1], 2) +
                Math.pow(vertices[i][2] - vertices[j][2], 2)
            );
            if (Math.abs(d - 2 * scale) < 5) edges.push([i, j]);
        }
    }
    
    function rotateY(v, a) {
        return [
            v[0] * Math.cos(a) + v[2] * Math.sin(a),
            v[1],
            -v[0] * Math.sin(a) + v[2] * Math.cos(a)
        ];
    }
    
    function rotateX(v, a) {
        return [
            v[0],
            v[1] * Math.cos(a) - v[2] * Math.sin(a),
            v[1] * Math.sin(a) + v[2] * Math.cos(a)
        ];
    }
    
    function project(v) {
        const fov = 400;
        const z = v[2] + 300;
        const factor = fov / z;
        return [
            canvas.width / 2 + v[0] * factor,
            canvas.height / 2 + v[1] * factor,
            z
        ];
    }
    
    function draw() {
        ctx.fillStyle = '#0a0e14';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Rotate vertices
        const rotated = vertices.map(v => {
            let rv = rotateY(v, angle);
            rv = rotateX(rv, angle * 0.6);
            return project(rv);
        });
        
        // Draw edges
        edges.forEach(([i, j]) => {
            const avgZ = (rotated[i][2] + rotated[j][2]) / 2;
            const alpha = 0.3 + (avgZ - 100) / 400;
            ctx.strokeStyle = `rgba(46, 116, 181, ${Math.min(Math.max(alpha, 0.1), 0.9)})`;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(rotated[i][0], rotated[i][1]);
            ctx.lineTo(rotated[j][0], rotated[j][1]);
            ctx.stroke();
        });
        
        // Draw vertices
        rotated.forEach((v, i) => {
            const alpha = 0.4 + (v[2] - 100) / 400;
            ctx.fillStyle = `rgba(0, 200, 150, ${Math.min(Math.max(alpha, 0.2), 1)})`;
            ctx.beginPath();
            ctx.arc(v[0], v[1], 4, 0, Math.PI * 2);
            ctx.fill();
        });
        
        // Labels
        ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
        ctx.font = '12px Georgia';
        ctx.fillText('24 vertices · 36 edges · 14 faces', 20, 30);
        ctx.fillText('6 squares + 8 hexagons', 20, 50);
        ctx.fillText('Oh symmetry group (order 48)', 20, 70);
        
        angle += 0.005;
        requestAnimationFrame(draw);
    }
    
    draw();
})();
